
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_datahub_bundle = "/bundles/pimcoredatahub/studio/build/440ad1f92aaf/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_datahub_bundle = "/plugins"
    