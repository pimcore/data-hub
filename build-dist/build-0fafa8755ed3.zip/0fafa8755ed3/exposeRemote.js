
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_datahub_bundle = "/bundles/pimcoredatahub/studio/build/0fafa8755ed3/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_datahub_bundle = "/plugins"
    