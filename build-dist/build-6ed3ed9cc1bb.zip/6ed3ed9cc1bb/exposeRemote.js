
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_datahub_bundle = "/bundles/pimcoredatahub/studio/build/6ed3ed9cc1bb/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_datahub_bundle = "/plugins"
    