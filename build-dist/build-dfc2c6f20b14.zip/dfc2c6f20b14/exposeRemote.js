
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_datahub_bundle = "/bundles/pimcoredatahub/studio/build/dfc2c6f20b14/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_datahub_bundle = "/plugins"
    